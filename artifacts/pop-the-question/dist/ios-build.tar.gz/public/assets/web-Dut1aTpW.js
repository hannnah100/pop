import{W as n}from"./index-DJxR37oC.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
